import { configureStore, createSlice } from '@reduxjs/toolkit'


import user from './store/userSlice.js'

let cart = createSlice({ 
  //cart에 대한 action과 reduce를 통합 함수 선언 
  name: 'cart',     //cart
  initialState: [   //cart의 초기값 설정
    { id: 0, name: 'White and Black', count: 2 },
    { id: 1, name: 'Grey Yordan', count: 1 },
    { id: 2, name: 'what', count: 1 },
    { id: 3, name: 'the', count: 7},
    { id: 4, name: 'Knit', count: 5 },
    { id: 5, name: 'Red', count: 10 },
    { id: 6, name: 'color', count: 1 },
    { id: 7, name: 'you', count: 0 }
  ],
  reducers : {
    addCount(state, action) {   //그냥 state 보여지는 값이
      // state[action.payload].count ++
      let 번호 = state.findIndex((parameter) => parameter.id === action.payload ) //parameter의 id 값이 action의 payload가 같다면
      state[번호].count++
      //payload와 같은 id가진 상품을 찾아서  +1
      //a는 state 어레이 에 있던 하나 하나의 자료이다
    },
    removeCount(state, action) {   //그냥 state 보여지는 값이
      // state[action.payload].count ++
      let 번호 = state.findIndex((parameter) => parameter.id === action.payload ) //parameter의 id 값이 action의 payload가 같다면
      state[번호].count--
      //payload와 같은 id가진 상품을 찾아서  +1
      //a는 state 어레이 에 있던 하나 하나의 자료이다
    }
    ,
    addItem(state, action) {
      //addItem( {id : 2, name : 'Grey Yordan', count : 1} ) 
      //1번상품만 추가됨
      //array뒤에 자료 추가해주는 함수
      //state.push({id : 1, name : 'Red Knit', count : 1})
      state.push(action.payload)
    }
  }
})
//addItem({id : 2, name : 'Gary Yordan', count : 1})
//state[action.payload].count++ 의미는 addConunt(0) 0번째 상품 + 1 해주는 기능인듯
export let { addCount, removeCount, addItem } = cart.actions

export default configureStore({
  reducer: {
    user: user.reducer,
    cart: cart.reducer
  }
}) 