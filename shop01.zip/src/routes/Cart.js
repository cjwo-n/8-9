import {Table} from 'react-bootstrap' 
import { useDispatch , useSelector } from "react-redux"

import { increase } from "./../store/userSlice.js"
import { addCount } from './../store.js'
import { removeCount } from './../store.js'

function Cart(){

let state = useSelector((state) =>  state )
// console.log(state.cart[0].name)

let dispatch = useDispatch()
// createSlice를 통한 action과 reduce동시에 사용 
    return(
        <div>
            {/* userSlice에 state에 user name 호출,user slice에  */}
            {/* h6 state user  */}
            <h6>{state.user.name} {state.user.age}의 장바구니 출력해보기</h6>
            <button onClick={()=>{ dispatch(increase(10))}}>버튼</button>
            <Table>
                <thead>
                    <tr>
                        <th>code</th>
                        <th>상품명</th>
                        <th>수량</th>
                        <th>변경하기</th>
                        <th>수량 변경</th>
                        
                    </tr>
                </thead>
                <tbody>
                    {
                        state.cart.map((a, i) =>
                            <tr key={i}>
                                <td>{state.cart[i].id}</td>
                                <td>{state.cart[i].name}</td>
                                <td>{state.cart[i].count}</td>
                                <td>안녕</td>
                                   <button onClick={()=>{
                                    dispatch(addCount(state.cart[i].id)) 
                                   }}> + </button> 
                                   <button onClick={()=>{
                                    dispatch(removeCount(state.cart[i].id)) 
                                   }}> - </button> 
                            </tr>
                        )
                    }
                </tbody>
            </Table>

        </div>
    )
}

export default Cart
